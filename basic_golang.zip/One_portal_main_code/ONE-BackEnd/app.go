package main

import (
	"fmt"

	"github.com/gofiber/fiber/v2"
	"github.com/gofiber/fiber/v2/middleware/cache"

	// "github.com/gofiber/fiber/v2/middleware/compress"
	"github.com/gofiber/fiber/v2/middleware/cors"
	// "github.com/gofiber/fiber/v2/middleware/csrf"
	// "github.com/gofiber/fiber/v2/middleware/encryptcookie"
	// "github.com/gofiber/fiber/v2/middleware/envvar"
	"github.com/gofiber/fiber/v2/middleware/etag"
	// mwexpvar "github.com/gofiber/fiber/v2/middleware/expvar"
	// "github.com/gofiber/fiber/v2/middleware/limiter"
	"github.com/gofiber/fiber/v2/middleware/logger"
	// "github.com/gofiber/fiber/v2/middleware/monitor"
	// "github.com/gofiber/fiber/v2/middleware/pprof"
	"github.com/gofiber/fiber/v2/middleware/recover"
	"github.com/gofiber/fiber/v2/middleware/requestid"

	// "github.com/gofiber/fiber/v2/middleware/skip"

	raccount "one/app/route/account"
	ruser "one/app/route/user"

	rannouncement "one/app/route/announcement"
	rfile "one/app/route/file"
	"one/pkg/settings"
)

func New() *fiber.App {
	app := fiber.New(settings.FiberConfig)

	// Used for debugging and monitoring
	// app.Use("/expose/envvars", envvar.New(settings.EnvVarConfig))
	// app.Use(mwexpvar.New(settings.ExpvarConfig)) // debug/vars
	// app.Use(pprof.New(settings.PprofConfig)) // debug/pprof
	// app.Get("/metrics", monitor.New(settings.MonitorConfig))

	app.Use(
		recover.New(settings.RecoverConfig),
		// compress.New(settings.CompressConfig),
		// encryptcookie.New(settings.EncryptCookieConfig),
		logger.New(settings.LoggerConfig),
		requestid.New(settings.RequestIDConfig),
		// limiter.New(settings.LimiterConfig),
		cors.New(settings.CORSConfig),
		// csrf.New(settings.CSRFConfig), // Disabled due to performance issue
		etag.New(settings.ETagConfig),
		cache.New(settings.CacheConfig),
	)

	// Skip if proxy not trusted
	// app.Use(skip.New(func(c *fiber.Ctx) error {
	// 	return c.SendStatus(fiber.StatusForbidden)
	// }, func(c *fiber.Ctx) bool {
	// 	return c.IsProxyTrusted()
	// }))

	api := app.Group("/api")

	v1 := api.Group("/v1")

	raccount.Route(v1)

	ruser.Route(v1)

	rfile.Route(v1)

	rannouncement.Route(v1)

	app.Use(func(c *fiber.Ctx) error {
		return c.SendStatus(fiber.StatusNotFound)
	})

	app.Hooks().OnListen(func() error {
		fmt.Println("listening...")

		return nil
	})

	app.Hooks().OnShutdown(func() error {
		fmt.Println("shutting down...")

		return nil
	})

	return app
}
