package mysql

import (
	"context"
	"database/sql"
	"fmt"
	"time"

	_ "github.com/go-sql-driver/mysql"
)

var (
	DB *sql.DB
	Conn *sql.Conn
)

func Open(user, pass, host, port, name string, timeout time.Duration) (*sql.DB, *sql.Conn, context.Context, context.CancelFunc, error) {
	ctx, cancel := context.WithTimeout(context.Background(), timeout)

	dsn := fmt.Sprintf(
		"%s:%s@%s(%s:%s)/%s?charset=%s&collation=%s&interpolateParams=%t&loc=%s&multiStatements=%t&parseTime=%t&sql_mode=%s&time_zone=%s",
		user,
		pass,
		"tcp",
		host,
		port,
		name,
		"utf8mb4,utf8",
		"utf8mb4_general_ci",
		false,
		time.UTC,
		false,
		true,
		"%27%27", // ''
		"%27%2B00%3A00%27", // '+00:00'
	)

	db, _ := sql.Open("mysql", dsn)

	conn, err := db.Conn(ctx)

	return db, conn, ctx, cancel, err
}

func Close(db *sql.DB, conn *sql.Conn) error {
	err := conn.Close()

	_ = db.Close()

	return err
}

func Ping(conn *sql.Conn, ctx context.Context) error {
	return conn.PingContext(ctx)
}
