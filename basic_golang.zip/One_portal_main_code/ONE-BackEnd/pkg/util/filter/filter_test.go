package filter

import "testing"

// go test -v -run=^$ -bench=Benchmark_Filter_MySQL_ParseFilter -benchmem -count=4
func Benchmark_Filter_MySQL_ParseFilter(b *testing.B) {

	b.ReportAllocs()

	b.ResetTimer()

	for n := 0; n < b.N; n++ {
		query := Query{}

		filter := Map{}

		args := []interface{}{}

		_ = FilterParser(&MySQL{ query, filter, &args })
	}
}
