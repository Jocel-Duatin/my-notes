package filter

import (
	"encoding/json"
	"fmt"
	"log"
	"strconv"
	"strings"
	"time"

	"go.mongodb.org/mongo-driver/bson"
)

type Map map[string]interface{}

type Query struct {
	Filter struct {
		Bool struct {
			Active string `json:"active,omitempty" query:"active"`
			Test string `json:"test,omitempty" query:"test"`
		} `json:"bool,omitempty" query:"bool"`
		Date struct {
			Birthday []string `json:"birthday,omitempty" query:"birthday"`
			DateTime []string `json:"datetime,omitempty" query:"datetime"`
			Created []string `json:"created,omitempty" query:"created"`
			LastModified []string `json:"lastmodified,omitempty" query:"lastmodified"`
		} `json:"date,omitempty" query:"date"`
		Int struct {
			Code string `json:"code,omitempty" query:"code"`
			Status string `json:"status,omitempty" query:"status"`
		} `json:"int,omitempty" query:"int"`
		String struct {
			Firstname string `json:"firstname,omitempty" query:"firstname"`
			Lastname string `json:"lastname,omitempty" query:"lastname"`
			EmailAddress string `json:"emailaddress,omitempty" query:"emailaddress"`
			Sex string `json:"sex,omitempty" query:"sex"`
		} `json:"string,omitempty" query:"string"`
	} `json:"filter,omitempty" query:"filter"`
}

type Service interface {
	ParseFilter() error
}

type MongoDB struct {
	Query
	Filter bson.M
}

type MySQL struct {
	Query
	Filter Map
	Args *[]interface{}
}

func FilterParser(service Service) error {
	return service.ParseFilter()
}

func(m *MongoDB) ParseFilter() error {
	query := Map{}

	b, _ := json.Marshal(m.Query)

	if err := json.Unmarshal(b, &query); err != nil {
		log.Print(err)

		return err
	}

	filter := m.Filter

	filter["$or"] = []bson.M{}

	filter["$and"] = []bson.M{}

	for tag, data := range query["filter"].(map[string]interface{}) {
		switch tag {
		case "bool":
			for key, val := range data.(map[string]interface{}) {
				b, err := strconv.ParseBool(val.(string))
				if err != nil {
					return err
				}

				filter["$or"] = append(filter["$or"].([]bson.M), bson.M{ key: b})
			}
		case "int":
			for key, val := range data.(map[string]interface{}) {
				i, err := strconv.Atoi(val.(string))
				if err != nil {
					return err
				}

				filter["$or"] = append(filter["$or"].([]bson.M), bson.M{ key: i})
			}
		case "date":
			for key, val := range data.(map[string]interface{}) {
				for _, date := range val.([]interface{}) {
					if strings.TrimSpace(date.(string)) != "" {
						dates := strings.Split(date.(string), ",")

						t, err := time.Parse(time.RFC3339, dates[0])
						if err != nil {
							return err
						}

						if len(dates) == 2 {
							if strings.ToLower(dates[1]) == "gte" {
								filter["$and"] = append(filter["$and"].([]bson.M), bson.M{ key: bson.M{ "$gte": t } })
							} else if strings.ToLower(dates[1]) == "lte" {
								filter["$and"] = append(filter["$and"].([]bson.M), bson.M{ key: bson.M{ "$lte": t } })
							}
						} else {
							filter["$and"] = append(filter["$and"].([]bson.M), bson.M{ key: t})
						}
					}
				}
			}
		case "string":
			for key, val := range data.(map[string]interface{}) {
				filter["$or"] = append(filter["$or"].([]bson.M), bson.M{ key: bson.M{ "$regex": val.(string), "$options": "i" }})
			}
		}
	}

	if len(filter["$or"].([]bson.M)) == 0 {
		delete(filter, "$or")
	}

	if len(filter["$and"].([]bson.M)) == 0 {
		delete(filter, "$and")
	}

	return nil
}

func(m *MySQL) ParseFilter() error {
	query := Map{}

	b, _ := json.Marshal(m.Query)

	if err := json.Unmarshal(b, &query); err != nil {
		log.Print(err)

		return err
	}

	filter := m.Filter

	filter["OR"] = []string{}

	filter["AND"] = []string{}

	args := m.Args

	for tag, data := range query["filter"].(map[string]interface{}) {
		switch tag {
		case "bool":
			for key, val := range data.(map[string]interface{}) {
				b, err := strconv.ParseBool(val.(string))
				if err != nil {
					return err
				}

				filter["OR"] = append(filter["OR"].([]string), fmt.Sprintf("%s = ?", key))

				*args = append(*args, b)
			}
		case "int":
			for key, val := range data.(map[string]interface{}) {
				i, err := strconv.Atoi(val.(string))
				if err != nil {
					return err
				}

				filter["OR"] = append(filter["OR"].([]string), fmt.Sprintf("%s = ?", key))

				*args = append(*args, i)
			}
		case "date":
			for key, val := range data.(map[string]interface{}) {
				for _, date := range val.([]interface{}) {
					if strings.TrimSpace(date.(string)) != "" {
						dates := strings.Split(date.(string), ",")

						t, err := time.Parse(time.RFC3339, dates[0])
						if err != nil {
							return err
						}

						dt := t.Format("2006-01-02 15:04:05")

						if len(dates) == 2 {
							if strings.ToLower(dates[1]) == "gte" {
								filter["AND"] = append(filter["AND"].([]string), fmt.Sprintf("%s >= ?", key))
							} else if strings.ToLower(dates[1]) == "lte" {
								filter["AND"] = append(filter["AND"].([]string), fmt.Sprintf("%s <= ?", key))
							}
						} else {
							filter["AND"] = append(filter["AND"].([]string), fmt.Sprintf("%s = ?", key))
						}

						*args = append(*args, dt)
					}
				}
			}
		case "string":
			for key, val := range data.(map[string]interface{}) {
				filter["OR"] = append(filter["OR"].([]string), fmt.Sprintf("%s LIKE ?", key))

				*args = append(*args, "%" + val.(string) + "%")
			}
		}
	}

	if len(filter["OR"].([]string)) == 0 {
		delete(filter, "OR")
	}

	if len(filter["AND"].([]string)) == 0 {
		delete(filter, "AND")
	}

	return nil
}

func MySQLBuildFilter(data ...Map) (Map, []interface{}, error) {
	filter := Map{}

	filter["OR"] = []string{}

	filter["AND"] = []string{}

	args := []interface{}{}

	for _, val := range data {
		precedence := val["precedence"].(string)

		operator := val["operator"].(string)

		wildcard := val["wildcard"].(bool)

		filter[precedence] = append(filter[precedence].([]string), fmt.Sprintf("%s %s ?", val["key"].(string), operator))

		if wildcard {
			args = append(args, "%"+val["value"].(string)+"%")
		} else {
			args = append(args, val["value"])
		}
	}

	if len(filter["OR"].([]string)) == 0 {
		delete(filter, "OR")
	}

	if len(filter["AND"].([]string)) == 0 {
		delete(filter, "AND")
	}

	return filter, args, nil
}

func MySQLBuildUpdate(structure interface{}) ([]string, []interface{}, error) {
	data := Map{}

	b, _ := json.Marshal(structure)

	if err := json.Unmarshal(b, &data); err != nil {
		return nil, nil, err
	}

	update := []string{}

	args := []interface{}{}

	for key, val := range data {
		update = append(update, fmt.Sprintf("%s = ?", key))

		args = append(args, val)
	}

	return update, args, nil
}
