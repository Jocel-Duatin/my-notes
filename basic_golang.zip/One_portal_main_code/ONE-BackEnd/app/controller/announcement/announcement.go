package controller

import (
	"context"
	"fmt"
	"log"
	"strconv"
	"strings"

	"github.com/gofiber/fiber/v2"

	mannouncement "one/app/model/announcement"
	sannouncement "one/app/service/announcement"

	"one/pkg/settings"
	"one/pkg/util"
	ufilter "one/pkg/util/filter"
)

func GetAnnouncements(c *fiber.Ctx) error {
	fmt.Println("hello")
	ctx, cancel := context.WithTimeout(context.Background(), settings.Timeout)

	defer cancel()

	query := ufilter.Query{}

	if err := c.QueryParser(&query); err != nil {
		log.Print(err)

		return err
	}

	filter := ufilter.Map{}

	args := []interface{}{}

	if err := ufilter.FilterParser(&ufilter.MySQL{Query: query, Filter: filter, Args: &args}); err != nil {
		log.Print(err)

		return err
	}

	total, err := sannouncement.Count(ctx, filter, args)
	if err != nil {
		log.Print(err)

		return err
	}

	page, _ := strconv.Atoi(c.Query("page", "1"))

	if page <= 0 {
		page = 1
	}

	limit, _ := strconv.Atoi(c.Query("limit", "10"))

	offset := (page - 1) * limit

	sorts := strings.Split(c.Query("sort"), ",")

	order, sort := "id", "asc"

	if strings.TrimSpace(sorts[0]) != "" {
		if util.Search(util.Names(mannouncement.Announcement{}), sorts[0], false) != -1 {
			order = sorts[0]
		}
	}

	if len(sorts) == 2 {
		if strings.ToLower(sorts[1]) == "asc" || strings.ToLower(sorts[1]) == "desc" {
			sort = strings.ToUpper(sorts[1])
		}
	}

	users, err := sannouncement.Fetch(ctx, filter, args, order, sort, limit, offset)
	if err != nil {
		log.Print(err)

		return err
	}

	if len(users) == 0 {
		return c.JSON(fiber.Map{"response": nil, "total": total})
	}

	return c.JSON(fiber.Map{"response": users, "total": total})
}
