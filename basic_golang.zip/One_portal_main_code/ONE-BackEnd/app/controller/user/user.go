package controller

import (
	"context"
	"database/sql"
	"log"
	"strconv"
	"strings"
	
	"github.com/gofiber/fiber/v2"

	muser "one/app/model/user"
	suser "one/app/service/user"

	"one/pkg/settings"
	"one/pkg/util"
	ufilter "one/pkg/util/filter"
	"one/pkg/util/validate"
)

func AddUser(c *fiber.Ctx) error {
	ctx, cancel := context.WithTimeout(context.Background(), settings.Timeout)

	defer cancel()

	user := new(muser.User)

	if err := c.BodyParser(user); err != nil {
		log.Print(err)

		return c.SendStatus(fiber.StatusUnprocessableEntity)
	}

	if invalid := validate.All(user); len(invalid) > 0 {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{ "response": invalid })
	}

	lastInsertId, err := suser.Insert(ctx, user)
	if err != nil {
		log.Print(err)

		return err
	}

	return c.Status(fiber.StatusCreated).JSON(fiber.Map{ "response": fiber.Map{ "lastInsertId": lastInsertId } })
}

func GetUser(c *fiber.Ctx) error {
	ctx, cancel := context.WithTimeout(context.Background(), settings.Timeout)

	defer cancel()

	id, err := strconv.Atoi(c.Params("id"))
	if err != nil {
		if c.Params("id") != "" {
			log.Print(err)

			return c.SendStatus(fiber.StatusBadRequest)
		}
	}

	user, err := suser.Get(ctx, id)
	if err != nil {
		if err == sql.ErrNoRows {
			log.Print(err)

			return c.SendStatus(fiber.StatusNotFound)
		} else {
			log.Print(err)

			return err
		}
	}

	return c.JSON(fiber.Map{ "response": user })
}

func GetUsers(c *fiber.Ctx) error {
	ctx, cancel := context.WithTimeout(context.Background(), settings.Timeout)

	defer cancel()

	query := ufilter.Query{}

	if err := c.QueryParser(&query); err != nil {
		log.Print(err)

		return err
	}

	filter := ufilter.Map{}

	args := []interface{}{}

	if err := ufilter.FilterParser(&ufilter.MySQL{ Query: query, Filter: filter, Args: &args }); err != nil {
		log.Print(err)

		return err
	}

	total, err := suser.Count(ctx, filter, args)
	if err != nil {
		log.Print(err)

		return err
	}

	page, _ := strconv.Atoi(c.Query("page", "1"))

	if page <= 0 {
		page = 1
	}

	limit, _ := strconv.Atoi(c.Query("limit", "10"))

	offset := (page - 1) * limit

	sorts := strings.Split(c.Query("sort"), ",")

	order, sort := "id", "asc"

	if strings.TrimSpace(sorts[0]) != "" {
		if util.Search(util.Names(muser.User{}), sorts[0], false) != -1 {
			order = sorts[0]
		}
	}

	if len(sorts) == 2 {
		if strings.ToLower(sorts[1]) == "asc" || strings.ToLower(sorts[1]) == "desc" {
			sort = strings.ToUpper(sorts[1])
		}
	}

	users, err := suser.Fetch(ctx, filter, args, order, sort, limit, offset)
	if err != nil {
		log.Print(err)

		return err
	}

	if len(users) == 0 {
		return c.JSON(fiber.Map{ "response": nil, "total": total  })
	}

	return c.JSON(fiber.Map{ "response": users, "total": total  })
}

func ReplaceUser(c *fiber.Ctx) error {
	ctx, cancel := context.WithTimeout(context.Background(), settings.Timeout)

	defer cancel()

	id, err := strconv.Atoi(c.Params("id"))
	if err != nil {
		if c.Params("id") != "" {
			log.Print(err)

			return c.SendStatus(fiber.StatusBadRequest)
		}
	}

	user := new(muser.User)

	if err := c.BodyParser(user); err != nil {
		log.Print(err)

		return c.SendStatus(fiber.StatusUnprocessableEntity)
	}

	user.Id = id

	if invalid := validate.All(user); len(invalid) > 0 {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{ "response": invalid })
	}

	lastInsertId, rowsAffected, err := suser.Replace(ctx, user)
	if err != nil {
		log.Print(err)

		return err
	}

	if rowsAffected > 1 {
		return c.JSON(fiber.Map{ "response": fiber.Map{ "lastInsertId": lastInsertId, "rowsAffected": rowsAffected } })
	}

	return c.Status(fiber.StatusCreated).JSON(fiber.Map{ "response": fiber.Map{ "lastInsertId": lastInsertId, "rowsAffected": rowsAffected } })
}

func UpdateUser(c *fiber.Ctx) error {
	ctx, cancel := context.WithTimeout(context.Background(), settings.Timeout)

	defer cancel()

	id, err := strconv.Atoi(c.Params("id"))
	if err != nil {
		if c.Params("id") != "" {
			log.Print(err)

			return c.SendStatus(fiber.StatusBadRequest)
		}
	}

	if _, err := suser.Get(ctx, id); err != nil {
		if err == sql.ErrNoRows {
			log.Print(err)

			return c.SendStatus(fiber.StatusNotFound)
		} else {
			log.Print(err)

			return err
		}
	}

	user := new(muser.User)

	if err := c.BodyParser(user); err != nil {
		log.Print(err)

		return c.SendStatus(fiber.StatusUnprocessableEntity)
	}

	update, args, err := ufilter.MySQLBuildUpdate(user)
	if err != nil {
		log.Print(err)

		return err
	}

	rowsAffected, err := suser.Update(ctx, update, args, id)
	if err != nil {
		log.Print(err)

		return err
	}

	return c.JSON(fiber.Map{ "response": fiber.Map{ "rowsAffected": rowsAffected } })
}

func DeleteUser(c *fiber.Ctx) error {
	ctx, cancel := context.WithTimeout(context.Background(), settings.Timeout)

	defer cancel()

	id, err := strconv.Atoi(c.Params("id"))
	if err != nil {
		if c.Params("id") != "" {
			log.Print(err)

			return c.SendStatus(fiber.StatusBadRequest)
		}
	}

	if _, err := suser.Get(ctx, id); err != nil {
		if err == sql.ErrNoRows {
			log.Print(err)

			return c.SendStatus(fiber.StatusNotFound)
		} else {
			log.Print(err)

			return err
		}
	}

	rowsAffected, err := suser.Delete(ctx, id)
	if err != nil {
		log.Print(err)

		return err
	}

	return c.JSON(fiber.Map{ "response": fiber.Map{ "rowsAffected": rowsAffected } })
}
