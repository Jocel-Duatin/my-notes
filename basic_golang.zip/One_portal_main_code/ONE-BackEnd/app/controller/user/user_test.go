package controller

import (
	// "fmt"
	// "io"
	"net/http/httptest"
	"os"
	"testing"
	"time"

	"github.com/gofiber/fiber/v2"
	"github.com/gofiber/fiber/v2/utils"

	"github.com/joho/godotenv"

	"github.com/valyala/fasthttp"

	"one/pkg/database/mysql"
)

func init() {
	_ = godotenv.Load("../../../.env")
}

func setup() {
	db, conn, ctx, _, err := mysql.Open(
		os.Getenv("MYSQL_USER"),
		os.Getenv("MYSQL_PASS"),
		os.Getenv("MYSQL_HOST"),
		os.Getenv("MYSQL_PORT"),
		os.Getenv("MYSQL_NAME"),
		15 * time.Second,
	)
	if err != nil {
		panic(err)
	}

	_ = mysql.Ping(conn, ctx)

	mysql.DB, mysql.Conn = db, conn
}

// go test -v -run Test_User_GetUsers
func Test_User_GetUsers(t *testing.T) {
	setup()

	app := fiber.New()

	app.Use("/", GetUsers)

	req := httptest.NewRequest(fiber.MethodGet, "/", nil)

	resp, err := app.Test(req, -1)

	utils.AssertEqual(t, nil, err)

	utils.AssertEqual(t, fiber.StatusOK, resp.StatusCode)
}

// go test -v -run=^$ -bench=Benchmark_User_GetUsers -benchmem -count=4
func Benchmark_User_GetUsers(b *testing.B) {
	setup()

	app := fiber.New()

	app.Use("/", GetUsers)

	h := app.Handler()

	fctx := new(fasthttp.RequestCtx)

	fctx.Request.Header.SetMethod(fiber.MethodGet)

	fctx.Request.SetRequestURI("/")

	b.ReportAllocs()

	b.ResetTimer()

	for n := 0; n < b.N; n++ {
		h(fctx)
	}

	utils.AssertEqual(b, fiber.StatusOK, fctx.Response.Header.StatusCode())
}
