package controller

import (
	"bytes"
	"context"
	"database/sql"
	"encoding/json"
	"html/template"
	"log"
	"os"
	"time"

	"github.com/gofiber/fiber/v2"
	"github.com/gofiber/fiber/v2/utils"

	"golang.org/x/crypto/bcrypt"

	jwtv4 "github.com/golang-jwt/jwt/v4"

	gomailv2 "gopkg.in/gomail.v2"

	maccount "one/app/model/account"
	saccount "one/app/service/account"

	mtoken "one/app/model/token"
	stoken "one/app/service/token"

	"one/pkg/settings"
	"one/pkg/jwt"
	"one/pkg/mailer/gomail"
	"one/pkg/util"
	ufilter "one/pkg/util/filter"
	"one/pkg/util/validate"
)

func Register(c *fiber.Ctx) error {
	ctx, cancel := context.WithTimeout(context.Background(), settings.Timeout)

	defer cancel()

	c.Set(fiber.HeaderCacheControl, settings.CacheControlNoStore)

	account := new(maccount.Account)

	account.EmailAddress = c.FormValue("emailaddress")

	account.Password = c.FormValue("password")

	if invalid := validate.All(account); len(invalid) > 0 {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{ "response": invalid })
	}

	filter, args, err := ufilter.MySQLBuildFilter(
		ufilter.Map{ "key": "emailaddress", "value": account.EmailAddress, "precedence": "OR", "operator": "=", "wildcard": false },
	)
	if err != nil {
		log.Print(err)

		return err
	}

	total, err := saccount.Count(ctx, filter, args)
	if err != nil {
		log.Print(err)

		return err
	}

	if total > 0 {
		return c.SendStatus(fiber.StatusConflict)
	}

	b, err := bcrypt.GenerateFromPassword([]byte(account.Password), bcrypt.DefaultCost)
	if err != nil {
		log.Print(err)

		return err
	}

	account.Password = string(b)

	lastInsertId, err := saccount.Insert(ctx, account)
	if err != nil {
		log.Print(err)

		return err
	}

	accessToken, err := jwt.NewToken(
		lastInsertId,
		settings.ShortExpiration,
		nil,
		jwt.AccessTokenKey,
	)
	if err != nil {
		log.Print(err)

		return err
	}

	refreshToken, err := jwt.NewToken(
		lastInsertId,
		settings.LongExpiration,
		utils.UUID(),
		jwt.RefreshTokenKey,
	)
	if err != nil {
		log.Print(err)

		return err
	}

	return c.Status(fiber.StatusCreated).JSON(fiber.Map{
		"response": fiber.Map{
			"access_token": accessToken,
			"token_type": jwt.AuthScheme,
			"expires_in": settings.ShortExpiration.Seconds(),
			"refresh_token": refreshToken,
		},
	})
}

func Login(c *fiber.Ctx) error {
	ctx, cancel := context.WithTimeout(context.Background(), settings.Timeout)

	defer cancel()

	c.Set(fiber.HeaderCacheControl, settings.CacheControlNoStore)

	username := c.FormValue("username")

	password := c.FormValue("password")

	invalids := []validate.Map{}

	if invalid := validate.One("username", username, "required"); len(invalid) > 0 {
		invalids = append(invalids, invalid)
	}

	if invalid := validate.One("password", password, "required"); len(invalid) > 0 {
		invalids = append(invalids, invalid)
	}

	if len(invalids) > 0 {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{ "response": invalids })
	}

	filter, args, err := ufilter.MySQLBuildFilter(
		ufilter.Map{ "key": "emailaddress", "value": username, "precedence": "OR", "operator": "=", "wildcard": false },
		ufilter.Map{ "key": "username", "value": username, "precedence": "OR", "operator": "=", "wildcard": false },
	)
	if err != nil {
		log.Print(err)

		return err
	}

	limit := 1

	accounts, err := saccount.Fetch(ctx, filter, args, limit)
	if err != nil {
		log.Print(err)

		return err
	}

	if len(accounts) == 0 {
		return c.SendStatus(fiber.StatusNotFound)
	}

	if err := bcrypt.CompareHashAndPassword([]byte(accounts[0].Password), []byte(password)); err != nil {
		return c.SendStatus(fiber.StatusBadRequest)
	}

	if !accounts[0].Active {
		return c.SendStatus(fiber.StatusForbidden)
	}

	accessToken, err := jwt.NewToken(
		accounts[0].Id,
		settings.ShortExpiration,
		nil,
		jwt.AccessTokenKey,
	)
	if err != nil {
		log.Print(err)

		return err
	}

	refreshToken, err := jwt.NewToken(
		accounts[0].Id,
		settings.LongExpiration, 
		utils.UUID(),
		jwt.RefreshTokenKey,
	)
	if err != nil {
		log.Print(err)

		return err
	}

	return c.JSON(fiber.Map{
		"response": fiber.Map{
			"access_token": accessToken,
			"token_type": jwt.AuthScheme,
			"expires_in": settings.ShortExpiration.Seconds(),
			"refresh_token": refreshToken,
		},
	})
}

func Refresh(c *fiber.Ctx) error {
	ctx, cancel := context.WithTimeout(context.Background(), settings.Timeout)

	defer cancel()

	claims := c.Locals("claims").(jwtv4.MapClaims)

	sub, _ := claims["sub"].(float64)

	id := int(sub)

	account, err := saccount.Get(ctx, id)
	if err != nil {
		if err == sql.ErrNoRows {
			log.Print(err)

			return c.SendStatus(fiber.StatusNotFound)
		} else {
			log.Print(err)

			return err
		}
	}

	if !account.Active {
		return c.SendStatus(fiber.StatusForbidden)
	}

	accessToken, err := jwt.NewToken(
		account.Id,
		settings.ShortExpiration,
		nil,
		jwt.AccessTokenKey,
	)
	if err != nil {
		log.Print(err)

		return err
	}

	refreshToken, err := jwt.NewToken(
		account.Id,
		settings.LongExpiration, 
		utils.UUID(),
		jwt.RefreshTokenKey,
	)
	if err != nil {
		log.Print(err)

		return err
	}

	return c.JSON(fiber.Map{
		"response": fiber.Map{
			"access_token": accessToken,
			"token_type": jwt.AuthScheme,
			"expires_in": settings.ShortExpiration.Seconds(),
			"refresh_token": refreshToken,
		},
	})
}

func Logout(c *fiber.Ctx) error {
	return c.SendStatus(fiber.StatusNoContent)
}

func Send(c *fiber.Ctx) error {
	ctx, cancel := context.WithTimeout(context.Background(), settings.Timeout)

	defer cancel()

	/* Find account */

	emailaddress := c.FormValue("emailaddress")

	filter, args, err := ufilter.MySQLBuildFilter(
		ufilter.Map{ "key": "emailaddress", "value": emailaddress, "precedence": "OR", "operator": "=", "wildcard": false },
	)
	if err != nil {
		log.Print(err)

		return err
	}

	limit := 1

	accounts, err := saccount.Fetch(ctx, filter, args, limit)
	if err != nil {
		log.Print(err)

		return err
	}

	if len(accounts) == 0 {
		return c.SendStatus(fiber.StatusNotFound)
	}

	if !accounts[0].Active {
		return c.SendStatus(fiber.StatusForbidden)
	}

	/* Find account */

	code := util.GenerateCode(settings.VerificationCodeLength)

	/* Store token */

	token := new(mtoken.Token)

	token.UserId = accounts[0].Id

	token.Value = code

	token.Type = settings.TokenTypeVerification

	expiration := time.Now().Add(settings.VerificationCodeExpiration)

	token.Expiration = &expiration

	if _, err := stoken.Insert(ctx, token); err != nil {
		log.Print(err)

		return err
	}

	/* Store token */

	/* Generate template */

	b, _ := os.ReadFile(settings.TemplateJSONFilename)

	t := map[string]interface{}{}

	_ = json.Unmarshal(b, &t)

	html := t["html"].(map[string]interface{})

	verification := html["verification"].(string)

	tmpl, err := template.ParseFiles(verification)
	if err != nil {
		log.Print(err)

		return err
	}

	writer := new(bytes.Buffer)

	data := struct{
		EmailAddress string
		Code string
		Firstname string
		Lastname string
	}{
		Firstname: accounts[0].Firstname,
		Lastname: accounts[0].Lastname,
		EmailAddress: accounts[0].EmailAddress,
		Code: code,
	}

	if err := tmpl.Execute(writer, data); err != nil {
		log.Print(err)

		return err
	}

	/* Generate template */

	body := writer.String()

	/* Send email */

	mailer := gomailv2.NewMessage()

	mailer.SetHeader("From", mailer.FormatAddress(gomail.From, gomail.Name))

	mailer.SetHeader("To", emailaddress)

	// mail.SetAddressHeader("Cc", "dan.rico@motivit.com")

	mailer.SetHeader("Subject", "gomail")

	mailer.SetBody("text/html", body)

	dialer := gomail.Dialer

	if err := dialer.DialAndSend(mailer); err != nil {
		return err
	}

	/* Send email */

	return c.SendStatus(fiber.StatusOK)
}

func Check(c *fiber.Ctx) error {
	ctx, cancel := context.WithTimeout(context.Background(), settings.Timeout)

	defer cancel()

	/* Find account */

	emailaddress := c.FormValue("emailaddress")

	filter, args, err := ufilter.MySQLBuildFilter(
		ufilter.Map{ "key": "emailaddress", "value": emailaddress, "precedence": "OR", "operator": "=", "wildcard": false },
	)
	if err != nil {
		log.Print(err)

		return err
	}

	limit := 1

	accounts, err := saccount.Fetch(ctx, filter, args, limit)
	if err != nil {
		log.Print(err)

		return err
	}

	if len(accounts) == 0 {
		return c.SendStatus(fiber.StatusNotFound)
	}

	if !accounts[0].Active {
		return c.SendStatus(fiber.StatusForbidden)
	}

	/* Find account */

	/* Find token */

	filter, args, err = ufilter.MySQLBuildFilter(
		ufilter.Map{ "key": "user_id", "value": accounts[0].Id, "precedence": "AND", "operator": "=", "wildcard": false },
		ufilter.Map{ "key": "type", "value": settings.TokenTypeVerification, "precedence": "AND", "operator": "=", "wildcard": false },
		ufilter.Map{ "key": "expiration", "value": time.Now(), "precedence": "AND", "operator": ">", "wildcard": false },
	)
	if err != nil {
		log.Print(err)

		return err
	}

	limit = 1

	offset := 0

	sort := "DESC"

	order := "expiration"

	tokens, err := stoken.Fetch(ctx, filter, args, order, sort, limit, offset)
	if err != nil {
		log.Print(err)

		return err
	}

	if len(tokens) == 0 {
		return c.SendStatus(fiber.StatusNotFound)
	}

	/* Find token */

	/* Check code */

	code := c.FormValue("code")

	if tokens[0].Value != code {
		return c.SendStatus(fiber.StatusBadRequest)
	}

	/* Check code */

	return c.SendStatus(fiber.StatusOK)
}
