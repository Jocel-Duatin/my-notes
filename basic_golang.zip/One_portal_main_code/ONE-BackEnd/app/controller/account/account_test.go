package controller

import (
	"bytes"
	// "fmt"
	// "io"
	"net/http/httptest"
	"net/url"
	"os"
	"testing"
	"time"

	"github.com/gofiber/fiber/v2"
	"github.com/gofiber/fiber/v2/utils"

	"github.com/joho/godotenv"

	"github.com/valyala/fasthttp"

	"one/pkg/database/mysql"
)

func init() {
	_ = godotenv.Load("../../../.env")
}

func setup() {
	db, conn, ctx, _, err := mysql.Open(
		os.Getenv("MYSQL_USER"),
		os.Getenv("MYSQL_PASS"),
		os.Getenv("MYSQL_HOST"),
		os.Getenv("MYSQL_PORT"),
		os.Getenv("MYSQL_NAME"),
		15 * time.Second,
	)
	if err != nil {
		panic(err)
	}

	_ = mysql.Ping(conn, ctx)

	mysql.DB, mysql.Conn = db, conn
}

// go test -v -run Test_Account_Login
func Test_Account_Login(t *testing.T) {
	setup()

	app := fiber.New()

	app.Use("/", Login)

	data := url.Values{}

	data.Add("username", "marc.martin@motivit.com")

	data.Add("password", "1234567890")

	req := httptest.NewRequest(fiber.MethodPost, "/", bytes.NewBufferString(data.Encode()))

	req.Header.Set(fiber.HeaderContentType, fiber.MIMEApplicationForm)

	resp, err := app.Test(req, -1)

	utils.AssertEqual(t, nil, err)

	utils.AssertEqual(t, fiber.StatusOK, resp.StatusCode)
}

// go test -v -run=^$ -bench=Benchmark_Account_Login -benchmem -count=4
func Benchmark_Account_Login(b *testing.B) {
	setup()

	app := fiber.New()

	app.Use("/", Login)

	h := app.Handler()

	fctx := new(fasthttp.RequestCtx)

	fctx.Request.Header.SetMethod(fiber.MethodPost)

	fctx.Request.SetRequestURI("/")

	data := url.Values{}

	data.Add("username", "marc.martin@motivit.com")

	data.Add("password", "1234567890")

	fctx.Request.SetBody([]byte(data.Encode()))

	fctx.Request.Header.Set(fiber.HeaderContentType, fiber.MIMEApplicationForm)

	b.ReportAllocs()

	b.ResetTimer()

	for n := 0; n < b.N; n++ {
		h(fctx)
	}

	utils.AssertEqual(b, fiber.StatusOK, fctx.Response.Header.StatusCode())
}
