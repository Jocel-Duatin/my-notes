package service

import (
	"context"
	"fmt"
	"strings"

	mannouncement "one/app/model/announcement"

	"one/pkg/database/mysql"
)

func Fetch(ctx context.Context, filter map[string]interface{}, args []interface{}, order, sort string, limit, offset int) ([]mannouncement.Announcement, error) {
	query := "SELECT * "

	query += "FROM announcement "

	if len(filter) > 0 {
		query += "WHERE "

		condition := []string{}

		for key, val := range filter {
			if _, ok := filter[key]; ok {
				condition = append(condition, strings.Join(val.([]string), fmt.Sprintf(" %s ", key)))
			}
		}

		query += strings.Join(condition, " AND ") + " "
	}

	query += fmt.Sprintf("ORDER BY %s %s ", order, sort)

	query += "LIMIT ? OFFSET ?"

	args = append(args, limit, offset)

	rows, err := mysql.DB.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, err
	}

	announcements := []mannouncement.Announcement{}

	for rows.Next() {
		announcement := mannouncement.Announcement{}

		if err := rows.Scan(
			&announcement.Id,
			&announcement.OfficeID,
			&announcement.Category,
			&announcement.Content,
			&announcement.Title,
			&announcement.DateAdded,
			&announcement.DateModified,
			&announcement.UserID,
			&announcement.IsGlobal,
		); err != nil {
			return nil, err
		}

		announcements = append(announcements, announcement)
	}

	if err := rows.Close(); err != nil {
		return nil, err
	}

	if err := rows.Err(); err != nil {
		return nil, err
	}

	return announcements, nil
}

func Count(ctx context.Context, filter map[string]interface{}, args []interface{}) (int, error) {
	query := "SELECT COUNT(*) "

	query += "FROM announcement "

	if len(filter) > 0 {
		query += "WHERE "

		condition := []string{}

		for key, val := range filter {
			if _, ok := filter[key]; ok {
				condition = append(condition, strings.Join(val.([]string), fmt.Sprintf(" %s ", key)))
			}
		}

		query += strings.Join(condition, " AND ") + " "
	}

	row := mysql.DB.QueryRowContext(ctx, query, args...)
	if err := row.Err(); err != nil {
		return 0, err
	}

	count := 0

	if err := row.Scan(&count); err != nil {
		return 0, err
	}

	return count, nil
}
