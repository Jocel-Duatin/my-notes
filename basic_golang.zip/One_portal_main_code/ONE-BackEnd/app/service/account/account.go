package service

import (
	"fmt"
	"context"
	"strings"

	maccount "one/app/model/account"

	"one/pkg/database/mysql"
)

func Insert(ctx context.Context, account *maccount.Account) (int64, error) {
	query := "INSERT "
	
	query += "INTO user(emailaddress, password) "

	query += "VALUES(?, ?)"

	res, err := mysql.DB.ExecContext(
		ctx,
		query,
		account.EmailAddress,
		account.Password,
	)
	if err != nil {
		return 0, err
	}

	return res.LastInsertId()
}

func Get(ctx context.Context, id int) (*maccount.Account, error) {
	query := "SELECT id, emailaddress, password, active, status "

	query += "FROM user "

	query += "WHERE id = ?"

	row := mysql.DB.QueryRowContext(ctx, query, id)
	if err := row.Err(); err != nil {
		return nil, err
	}

	account := new(maccount.Account)

	if err := row.Scan(
		&account.Id,
		&account.EmailAddress,
		&account.Password,
		&account.Active,
		&account.Status,
	); err != nil {
		return nil, err
	}

	return account, nil
}

func Count(ctx context.Context, filter map[string]interface{}, args []interface{}) (int, error) {
	query := "SELECT COUNT(*) "

	query += "FROM user "

	if len(filter) > 0 {
		query += "WHERE "

		condition := []string{}

		for key, val := range filter {
			if _, ok := filter[key]; ok {
				condition = append(condition, strings.Join(val.([]string), fmt.Sprintf(" %s ", key)))
			}
		}

		query += strings.Join(condition, " AND ") + " "
	}

	row := mysql.DB.QueryRowContext(ctx, query, args...)
	if err := row.Err(); err != nil {
		return 0, err
	}

	count := 0

	if err := row.Scan(&count); err != nil {
		return 0, err
	}

	return count, nil
}

func Fetch(ctx context.Context, filter map[string]interface{}, args []interface{}, limit int) ([]maccount.Account, error) {
	query := "SELECT id, firstname, lastname, emailaddress, password, active, status "

	query += "FROM user "

	if len(filter) > 0 {
		query += "WHERE "

		condition := []string{}

		for key, val := range filter {
			if _, ok := filter[key]; ok {
				condition = append(condition, strings.Join(val.([]string), fmt.Sprintf(" %s ", key)))
			}
		}

		query += strings.Join(condition, " AND ") + " "
	}

	query += "LIMIT ?"

	args = append(args, limit)

	rows, err := mysql.DB.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, err
	}

	accounts := []maccount.Account{}

	for rows.Next() {
		account := maccount.Account{}

		if err := rows.Scan(
			&account.Id,
			&account.Firstname,
			&account.Lastname,
			&account.EmailAddress,
			&account.Password,
			&account.Active,
			&account.Status,
		); err != nil {
			return nil, err
		}
	
		accounts = append(accounts, account)
	}

	if err := rows.Close(); err != nil {
		return nil, err
	}

	if err := rows.Err(); err != nil {
		return nil, err
	}

	return accounts, nil
}
