package service

import (
	"context"
	"fmt"
	"strings"

	muser "one/app/model/user"

	"one/pkg/database/mysql"
)

func Insert(ctx context.Context, user *muser.User) (int64, error) {
	query := "INSERT "

	query += "INTO user(firstname, lastname, username, emailaddress, password, birthday, sex, role) "

	query += "VALUES(?, ?, ?, ?, ?, ?, ?, ?)"

	res, err := mysql.DB.ExecContext(
		ctx,
		query,
		user.Firstname,
		user.Lastname,
		user.Username,
		user.EmailAddress,
		user.Password,
		user.Birthday,
		user.Sex,
		user.Role,
	)
	if err != nil {
		return 0, err
	}

	return res.LastInsertId()
}

func Get(ctx context.Context, id int) (*muser.User, error) {
	query := "SELECT * "

	query += "FROM user "

	query += "WHERE id = ?"

	row := mysql.DB.QueryRowContext(ctx, query, id)
	if err := row.Err(); err != nil {
		return nil, err
	}

	user := new(muser.User)

	if err := row.Scan(
		&user.Id,
		&user.Firstname,
		&user.Lastname,
		&user.Username,
		&user.EmailAddress,
		&user.Password,
		&user.Birthday,
		&user.Sex,
		&user.Role,
		&user.Active,
		&user.Status,
		&user.Created,
		&user.LastModified,
	); err != nil {
		return nil, err
	}

	return user, nil
}

func Count(ctx context.Context, filter map[string]interface{}, args []interface{}) (int, error) {
	query := "SELECT COUNT(*) "

	query += "FROM user "

	if len(filter) > 0 {
		query += "WHERE "

		condition := []string{}

		for key, val := range filter {
			if _, ok := filter[key]; ok {
				condition = append(condition, strings.Join(val.([]string), fmt.Sprintf(" %s ", key)))
			}
		}

		query += strings.Join(condition, " AND ") + " "
	}

	row := mysql.DB.QueryRowContext(ctx, query, args...)
	if err := row.Err(); err != nil {
		return 0, err
	}

	count := 0

	if err := row.Scan(&count); err != nil {
		return 0, err
	}

	return count, nil
}

func Fetch(ctx context.Context, filter map[string]interface{}, args []interface{}, order, sort string, limit, offset int) ([]muser.User, error) {
	query := "SELECT * "

	query += "FROM user "

	if len(filter) > 0 {
		query += "WHERE "

		condition := []string{}

		for key, val := range filter {
			if _, ok := filter[key]; ok {
				condition = append(condition, strings.Join(val.([]string), fmt.Sprintf(" %s ", key)))
			}
		}

		query += strings.Join(condition, " AND ") + " "
	}

	query += fmt.Sprintf("ORDER BY %s %s ", order, sort)

	query += "LIMIT ? OFFSET ?"

	args = append(args, limit, offset)

	rows, err := mysql.DB.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, err
	}

	users := []muser.User{}

	for rows.Next() {
		user := muser.User{}

		if err := rows.Scan(
			&user.Id,
			&user.Firstname,
			&user.Lastname,
			&user.Username,
			&user.EmailAddress,
			&user.Password,
			&user.Birthday,
			&user.Sex,
			&user.Role,
			&user.Active,
			&user.Status,
			&user.Created,
			&user.LastModified,
		); err != nil {
			return nil, err
		}
	
		users = append(users, user)
	}

	if err := rows.Close(); err != nil {
		return nil, err
	}

	if err := rows.Err(); err != nil {
		return nil, err
	}

	return users, nil
}

func Replace(ctx context.Context, user *muser.User) (int64, int64, error) {
	query := "REPLACE INTO user(id, firstname, lastname, username, emailaddress, password, birthday, sex, role) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)"

	res, err := mysql.DB.ExecContext(
		ctx,
		query,
		user.Id,
		user.Firstname,
		user.Lastname,
		user.Username,
		user.EmailAddress,
		user.Password,
		user.Birthday,
		user.Sex,
		user.Role,
	)
	if err != nil {
		return 0, 0, err
	}

	lastInsertId, err := res.LastInsertId()
	if err != nil {
		return 0, 0, err
	}

	rowsAffected, err := res.RowsAffected()
	if err != nil {
		return 0, 0, err
	}

	return lastInsertId, rowsAffected, nil
}

func Update(ctx context.Context, update []string, args []interface{}, id int) (int64, error) {
	query := "UPDATE user "

	query += "SET " +  strings.Join(update, ", ") + " "

	query += "WHERE id = ?"

	args = append(args, id)

	res, err := mysql.DB.ExecContext(ctx, query, args...)
	if err != nil {
		return 0, err
	}

	return res.RowsAffected()
}

func Delete(ctx context.Context, id int) (int64, error) {
	query := "DELETE "

	query += "FROM user "

	query += "WHERE id = ?"

	res, err := mysql.DB.ExecContext(ctx, query, id)
	if err != nil {
		return 0, err
	}

	return res.RowsAffected()
}
