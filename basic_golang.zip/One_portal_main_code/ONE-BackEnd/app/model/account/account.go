package model

type Account struct {
	Id int `form:"id"`
	Firstname string `json:"firstname"`
	Lastname string `json:"lastname"`
	EmailAddress string `form:"emailaddress" validate:"required,email"`
	Password string `form:"password" validate:"required"`
	Active bool `form:"active"`
	Status int `form:"status"`
}
