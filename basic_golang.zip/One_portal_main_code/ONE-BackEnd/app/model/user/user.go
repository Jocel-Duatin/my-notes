package model

import "time"

type User struct {
	Id int `json:"id,omitempty"`
	Firstname string `json:"firstname,omitempty" validate:"required"`
	Lastname string `json:"lastname,omitempty" validate:"required"`
	EmailAddress string `json:"emailaddress,omitempty" validate:"required,email"`
	Username string `json:"username,omitempty"`
	Password string `json:"password,omitempty"`
	Birthday *time.Time `json:"birthday,omitempty" validate:"required"`
	Sex string `json:"sex,omitempty" validate:"required"`
	Role string `json:"role,omitempty"`
	Active *bool `json:"active,omitempty"`
	Status int `json:"status,omitempty"`
	Created *time.Time `json:"created,omitempty"`
	LastModified *time.Time `json:"lastmodified,omitempty"`
}
