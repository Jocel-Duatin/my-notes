package model

import "time"

type Announcement struct {
	Id           int        `form:"id,omitempty"`
	OfficeID     int        `json:"office_id,omitempty"`
	Category     string     `json:"category,omitempty" validate:"required,email"`
	Content      string     `form:"content,omitempty" validate:"required"`
	Title        string     `form:"title,omitempty" validate:"required"`
	DateAdded    *time.Time `json:"date_added,omitempty" validate:"required"`
	DateModified *time.Time `json:"date_modified,omitempty" validate:"required"`
	UserID       int        `json:"user_id,omitempty"`
	IsGlobal     bool       `form:"is_global,omitempty"`
}
