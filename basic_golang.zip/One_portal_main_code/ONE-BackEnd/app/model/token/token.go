package model

import "time"

type Token struct {
	Id int `json:"id,omitempty"`
	UserId int `json:"user_id,omitempty"`
	Value string `json:"value,omitempty"`
	Type int `json:"type,omitempty"`
	Expiration *time.Time `json:"expiration,omitempty"`
	Created *time.Time `json:"created,omitempty"`
}
