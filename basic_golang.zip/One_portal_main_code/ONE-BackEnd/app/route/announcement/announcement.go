package route

import (
	"github.com/gofiber/fiber/v2"

	cannouncement "one/app/controller/announcement"

	hjwt "one/pkg/handler/jwt"
)

func Route(router fiber.Router) {
	router.Get("/announcement", hjwt.VerifyAccessToken, cannouncement.GetAnnouncements)

}
