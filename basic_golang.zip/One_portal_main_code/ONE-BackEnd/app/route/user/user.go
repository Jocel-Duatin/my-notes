package route

import (
	"github.com/gofiber/fiber/v2"

	cuser "one/app/controller/user"

	hjwt "one/pkg/handler/jwt"
)

func Route(router fiber.Router) {
	router.Post("/user", hjwt.VerifyAccessToken, cuser.AddUser)

	router.Get("/user/:id", hjwt.VerifyAccessToken, cuser.GetUser)

	router.Get("/user", hjwt.VerifyAccessToken, cuser.GetUsers)

	router.Put("/user/:id?", hjwt.VerifyAccessToken, cuser.ReplaceUser)

	router.Patch("/user/:id", hjwt.VerifyAccessToken, cuser.UpdateUser)

	router.Delete("/user/:id", hjwt.VerifyAccessToken, cuser.DeleteUser)

}
