package route

import (
	"github.com/gofiber/fiber/v2"

	hfile "one/pkg/handler/file"
	hjwt "one/pkg/handler/jwt"
)

func Route(router fiber.Router) {
	router.Post("/file", hjwt.VerifyAccessToken, hfile.Upload)

	router.Get("/file/:filename", hjwt.VerifyAccessToken, hfile.Download)
}
