package route

import (
	"github.com/gofiber/fiber/v2"

	caccount "one/app/controller/account"

	hjwt "one/pkg/handler/jwt"
)

func Route(router fiber.Router) {
	router.Post("/account/register", caccount.Register)

	router.Post("/account/login", caccount.Login)

	router.Post("/account/refresh", hjwt.VerifyRefreshToken, caccount.Refresh)

	router.Post("/account/logout", caccount.Logout)

	router.Post("/account/send", hjwt.VerifyAccessToken, caccount.Send)

	router.Post("/account/check", hjwt.VerifyAccessToken, caccount.Check)
}
