-- phpMyAdmin SQL Dump
-- version 5.1.1deb5ubuntu1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Dec 14, 2022 at 08:04 AM
-- Server version: 8.0.31-0ubuntu0.22.04.1
-- PHP Version: 8.1.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `one_dev`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`apps.dev`@`%` PROCEDURE `getCompanies` (IN `agentID` INT)  BEGIN
SET @agentID := agentID;
SELECT *
FROM
company as C
WHERE
@agentID = 1;


END$$

CREATE DEFINER=`apps.dev`@`%` PROCEDURE `getCompany` (IN `companyID` INT)  BEGIN

SET @companyID := companyID;

SELECT
	C.name as 'company',
    CM.meta_key,
    CM.meta_value,
    CASE
        WHEN CM.meta_key = 'announcement' 
        THEN (SELECT content 
            FROM 	announcement 
            WHERE id = CM.meta_value)
        WHEN CM.meta_key = 'account_manager' 
        THEN (SELECT CONCAT(U.first_name,' ',U.last_name)
            FROM account_manager as AM,
                users as U
            WHERE AM.id = CM.meta_value AND
                    AM.user_id = U.id
            )
        WHEN CM.meta_key = 'alt_method' 
        THEN (SELECT name
            FROM alt_method as AM
            WHERE AM.id = CM.meta_value 
            )
        ELSE 'n/a'
    END AS value
FROM company_meta as CM,
     company as C
WHERE
    C.id = @companyID AND
    CM.company_id = @companyId;

END$$

CREATE DEFINER=`apps.dev`@`%` PROCEDURE `getOffice` (IN `officeID` INT)  BEGIN

SET @officeID := officeID;

SELECT
C.name as 'company',
O.name as 'office',
OM.meta_key,
SH.title,
SH.coverage
FROM
office_meta as OM,
office as O,
support_hours as SH,
company as C
WHERE
O.id= @officeID AND
O.company_id = C.id AND
O.support_hours_id = SH.id;

END$$

CREATE DEFINER=`apps.dev`@`%` PROCEDURE `getOffices` (IN `companyID` INT)  BEGIN
SET @companyID := companyID;

SELECT
	   C.id as 'company_Id',
	   C.name as 'company',
       O.id as 'office_id',
	   O.name as 'office'
FROM
company as C,
office as O
WHERE
O.company_id =C.id AND
C.id = @companyID;

END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `account_manager`
--

CREATE TABLE `account_manager` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `position` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `is_primary` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `account_manager`
--

INSERT INTO `account_manager` (`id`, `user_id`, `position`, `is_primary`) VALUES
(1, 1, 'TAM', 1);

-- --------------------------------------------------------

--
-- Table structure for table `alt_method`
--

CREATE TABLE `alt_method` (
  `id` int NOT NULL,
  `office_id` int NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `image` text COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `alt_method`
--

INSERT INTO `alt_method` (`id`, `office_id`, `name`, `image`) VALUES
(1, 1, 'chat', '1');

-- --------------------------------------------------------

--
-- Table structure for table `announcement`
--

CREATE TABLE `announcement` (
  `id` int NOT NULL,
  `office_id` int NOT NULL,
  `category` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `content` text COLLATE utf8mb4_general_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `date_added` datetime NOT NULL,
  `date_modified` datetime NOT NULL,
  `user_id` int NOT NULL,
  `is_global` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `announcement`
--

INSERT INTO `announcement` (`id`, `office_id`, `category`, `content`, `title`, `date_added`, `date_modified`, `user_id`, `is_global`) VALUES
(1, 1, 'holiday', 'We wish you a very Happy Holiday season and a peaceful and prosperous New Year.', 'Christmas Holiday', '2022-12-13 08:18:22', '2022-12-13 08:18:22', 1, 1),
(2, 2, 'Monthly Web Maintenance', 'n/a', 'Monthly Web Maintenance', '2022-12-13 08:20:30', '2022-12-13 08:20:30', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `backup`
--

CREATE TABLE `backup` (
  `id` int NOT NULL,
  `office_id` int NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `device_name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `backup_type` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `backup_text` text COLLATE utf8mb4_general_ci NOT NULL,
  `backup_destination` text COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `checklist`
--

CREATE TABLE `checklist` (
  `id` int NOT NULL,
  `office_id` int NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `content` json NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

CREATE TABLE `company` (
  `id` int NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `logo` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `type` varchar(100) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `company`
--

INSERT INTO `company` (`id`, `name`, `logo`, `type`) VALUES
(1, 'MotivIT', 'MotivIT - Client_logo', ''),
(2, 'Manyish', '2', '');

-- --------------------------------------------------------

--
-- Table structure for table `company_meta`
--

CREATE TABLE `company_meta` (
  `id` int NOT NULL,
  `company_id` int NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `meta_value` text COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `company_meta`
--

INSERT INTO `company_meta` (`id`, `company_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'announcement', '1'),
(3, 1, 'alt_method', '1'),
(5, 1, 'account_manager', '1'),
(6, 1, 'osticket_id', ''),
(7, 1, 'hudu_id', ''),
(8, 2, 'account_manager', '1');

-- --------------------------------------------------------

--
-- Table structure for table `documentation`
--

CREATE TABLE `documentation` (
  `id` int NOT NULL,
  `office_id` int NOT NULL,
  `user_id` int NOT NULL,
  `user_modified_id` int NOT NULL,
  `filename` text COLLATE utf8mb4_general_ci NOT NULL,
  `type` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `parent` int NOT NULL,
  `doc_left` int NOT NULL,
  `doc_right` int NOT NULL,
  `date_added` datetime NOT NULL,
  `date_modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `id` int NOT NULL,
  `office_id` int NOT NULL,
  `first_name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `contact` varchar(255) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`id`, `office_id`, `first_name`, `last_name`, `email`, `contact`) VALUES
(1, 1, 'Ciro ', 'Reyes', 'ricocarbonel@gmail.com', '09676207531');

-- --------------------------------------------------------

--
-- Table structure for table `instant_support_item`
--

CREATE TABLE `instant_support_item` (
  `id` int NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `url` text COLLATE utf8mb4_general_ci NOT NULL,
  `description` text COLLATE utf8mb4_general_ci NOT NULL,
  `is_global` tinyint(1) NOT NULL,
  `type` varchar(50) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `instant_support_list`
--

CREATE TABLE `instant_support_list` (
  `id` int NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `items` json NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `integration`
--

CREATE TABLE `integration` (
  `id` int NOT NULL,
  `office_id` int NOT NULL,
  `itemp_id` int NOT NULL,
  `itemp_lookup_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `integration _meta`
--

CREATE TABLE `integration _meta` (
  `id` int NOT NULL,
  `integration_id` int NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `meta_value` text COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `integration_template`
--

CREATE TABLE `integration_template` (
  `id` int NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `user_id` int NOT NULL,
  `date_added` datetime NOT NULL,
  `last_modified_id` int NOT NULL,
  `last_modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `integration_temp_lookup`
--

CREATE TABLE `integration_temp_lookup` (
  `id` int NOT NULL,
  `itemp_id` int NOT NULL,
  `field` varchar(255) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mit_infra`
--

CREATE TABLE `mit_infra` (
  `id` int NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `user_id` int NOT NULL,
  `date_added` datetime NOT NULL,
  `last_modified_id` int NOT NULL,
  `last_modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mit_infra_table`
--

CREATE TABLE `mit_infra_table` (
  `id` int NOT NULL,
  `mit_infra_id` int NOT NULL,
  `company_id` int NOT NULL,
  `data` json NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `network_diagram`
--

CREATE TABLE `network_diagram` (
  `id` int NOT NULL,
  `office_id` int NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `image` text COLLATE utf8mb4_general_ci NOT NULL,
  `user_id` int NOT NULL,
  `date_added` datetime NOT NULL,
  `last_modified_id` int NOT NULL,
  `last_modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `office`
--

CREATE TABLE `office` (
  `id` int NOT NULL,
  `company_id` int NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `address` text COLLATE utf8mb4_general_ci NOT NULL,
  `support_hours_id` int NOT NULL,
  `working_hours` text COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `office`
--

INSERT INTO `office` (`id`, `company_id`, `name`, `address`, `support_hours_id`, `working_hours`) VALUES
(1, 1, 'North America HQ', '2880 Zanker Rd. Suite 203 San Jose, CA 95134', 1, ''),
(2, 1, 'APAC Office', '22/F, Centro, No. 568, Hengfeng Road, Zhabei District, Shanghai,\r\n200070, China', 1, ''),
(3, 1, 'Global Service Center', 'JTB Hub, Purok 1, Sto Domingo,\r\nNueva Ecija, 3133, Philippines', 1, ''),
(4, 2, 'Manyish HQ', 'Beijing, China', 1, '');

-- --------------------------------------------------------

--
-- Table structure for table `office_meta`
--

CREATE TABLE `office_meta` (
  `id` int NOT NULL,
  `office_id` int NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `meta_value` text COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `office_meta`
--

INSERT INTO `office_meta` (`id`, `office_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'resource', '1'),
(2, 1, 'instant_sup_list', '1'),
(3, 1, 'announcement', '1');

-- --------------------------------------------------------

--
-- Table structure for table `resource`
--

CREATE TABLE `resource` (
  `id` int NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `url` text COLLATE utf8mb4_general_ci NOT NULL,
  `is_global` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `id` int NOT NULL,
  `office_id` int NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `content` json NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `subscription`
--

CREATE TABLE `subscription` (
  `id` int NOT NULL,
  `subscription_temp_id` int NOT NULL,
  `company_id` int NOT NULL,
  `from_date` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `to_date` varchar(100) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `subscription_meta`
--

CREATE TABLE `subscription_meta` (
  `id` int NOT NULL,
  `subscription_id` int NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `meta_value` text COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `subscription_temp`
--

CREATE TABLE `subscription_temp` (
  `id` int NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `content` json NOT NULL,
  `user_id` int NOT NULL,
  `date_added` datetime NOT NULL,
  `date_modified_id` int NOT NULL,
  `date_modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `support_hours`
--

CREATE TABLE `support_hours` (
  `id` int NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `coverage` json NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `support_hours`
--

INSERT INTO `support_hours` (`id`, `title`, `coverage`) VALUES
(1, '24/7', '[{\"end\": \"6pm\", \"days\": \"weekdays\", \"start\": \"8am\", \"noc_type\": \"tier1\", \"timezone\": \"US/Pacific\"}]');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `first_name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `email_address` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `is_admin` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `photo` text COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `email_address`, `password`, `type`, `is_admin`, `is_active`, `photo`) VALUES
(1, 'rico', 'carbonel', 'ricocarbonel@gmail.com', '', 'agent', 1, 1, '1'),
(2, 'Ciro', 'Reyes', 'ricocarbonel@gmail.com', '', 'client', 0, 1, '1'),
(3, 'Aaron', 'Cacho', 'aaron.cacho@motivit.com', '$2a$10$nJc2btg8cJEZ857p79VyguxnEiPWnW6qfj3TCFwv/PqiyW9PYNWOq', 'agent', 1, 1, '0');

-- --------------------------------------------------------

--
-- Table structure for table `user_meta`
--

CREATE TABLE `user_meta` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `meta_value` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_meta`
--

INSERT INTO `user_meta` (`id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 2, 'office_id', '1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account_manager`
--
ALTER TABLE `account_manager`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `alt_method`
--
ALTER TABLE `alt_method`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `announcement`
--
ALTER TABLE `announcement`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `backup`
--
ALTER TABLE `backup`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `checklist`
--
ALTER TABLE `checklist`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `company`
--
ALTER TABLE `company`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `company_meta`
--
ALTER TABLE `company_meta`
  ADD PRIMARY KEY (`id`),
  ADD KEY `company_id` (`company_id`);

--
-- Indexes for table `documentation`
--
ALTER TABLE `documentation`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`id`),
  ADD KEY `office_id` (`office_id`);

--
-- Indexes for table `instant_support_item`
--
ALTER TABLE `instant_support_item`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `instant_support_list`
--
ALTER TABLE `instant_support_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `integration`
--
ALTER TABLE `integration`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `integration _meta`
--
ALTER TABLE `integration _meta`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `integration_template`
--
ALTER TABLE `integration_template`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `integration_temp_lookup`
--
ALTER TABLE `integration_temp_lookup`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mit_infra`
--
ALTER TABLE `mit_infra`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mit_infra_table`
--
ALTER TABLE `mit_infra_table`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `network_diagram`
--
ALTER TABLE `network_diagram`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `office`
--
ALTER TABLE `office`
  ADD PRIMARY KEY (`id`),
  ADD KEY `company_id` (`company_id`);

--
-- Indexes for table `office_meta`
--
ALTER TABLE `office_meta`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `resource`
--
ALTER TABLE `resource`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subscription`
--
ALTER TABLE `subscription`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subscription_meta`
--
ALTER TABLE `subscription_meta`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subscription_temp`
--
ALTER TABLE `subscription_temp`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `support_hours`
--
ALTER TABLE `support_hours`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_meta`
--
ALTER TABLE `user_meta`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `account_manager`
--
ALTER TABLE `account_manager`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `alt_method`
--
ALTER TABLE `alt_method`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `announcement`
--
ALTER TABLE `announcement`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `backup`
--
ALTER TABLE `backup`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `checklist`
--
ALTER TABLE `checklist`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `company`
--
ALTER TABLE `company`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `company_meta`
--
ALTER TABLE `company_meta`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `documentation`
--
ALTER TABLE `documentation`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `instant_support_item`
--
ALTER TABLE `instant_support_item`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `instant_support_list`
--
ALTER TABLE `instant_support_list`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `integration`
--
ALTER TABLE `integration`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `integration _meta`
--
ALTER TABLE `integration _meta`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `integration_template`
--
ALTER TABLE `integration_template`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `integration_temp_lookup`
--
ALTER TABLE `integration_temp_lookup`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mit_infra`
--
ALTER TABLE `mit_infra`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mit_infra_table`
--
ALTER TABLE `mit_infra_table`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `network_diagram`
--
ALTER TABLE `network_diagram`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `office`
--
ALTER TABLE `office`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `office_meta`
--
ALTER TABLE `office_meta`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `resource`
--
ALTER TABLE `resource`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `subscription`
--
ALTER TABLE `subscription`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `subscription_meta`
--
ALTER TABLE `subscription_meta`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `subscription_temp`
--
ALTER TABLE `subscription_temp`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `support_hours`
--
ALTER TABLE `support_hours`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `user_meta`
--
ALTER TABLE `user_meta`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
